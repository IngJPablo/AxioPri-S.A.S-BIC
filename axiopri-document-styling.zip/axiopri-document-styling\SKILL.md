---
name: axiopri-document-styling
description: >-
  Estiliza y genera informes academicos y corporativos de AxioPri S.A.S BIC bajo la identidad visual llanera-tech, estructurando las salidas en formatos compatibles con Google Docs y Microsoft Word para edicion inmediata.
---

# AxioPri Document Styling Skill

## Overview
Esta skill habilita a la IA para redactar, disenar y dar formato de manera automatica a cualquier informe tecnico, entrega universitaria (para la Universidad La Gran Colombia) o documento corporativo de **AxioPri S.A.S BIC**, plasmando fielmente su ADN llanero-tech. 

La skill esta optimizada para que los resultados generados puedan ser importados o copiados directamente en **Google Docs o Microsoft Word** sin perder su formato, sus colores corporativos, sus fuentes ni su estructura.

---

## 1. Brand Visual Tokens (Valores de Marca / Brand Colors)

La IA debe inyectar de manera obligatoria los siguientes parametros esteticos en el formato de cualquier documento:

*   **Paleta de Colores Llaneros (Brand Palette):**
    *   **Verde Moriche (Primary / Verde Esmeralda):** `#1F8C4E` (RGB: `31, 140, 78`) - Usado para titulos principales, acentos y bordes de tablas.
    *   **Dorado Llanero (Secondary / Gold / Dorado / Acento):** `#C8A94C` (RGB: `200, 169, 76`) - Usado para subtitulos, resaltados, detalles premium y decoraciones de marca.
    *   **Naranja Ocaso (Alert / Naranja / Accion):** `#E06A3B` (RGB: `224, 106, 59`) - Usado para destacados, llamadas de atencion y notas criticas.
    *   **Gris Lino (Light Background / Fondo de Lectura):** `#F4F6F4` (RGB: `244, 246, 244`) - Fondo sutil para bloques y tablas.
    *   **Verde Carbon (Dark Typography / Color de Texto):** `#121714` (RGB: `18, 23, 20`) - Color de texto primario (negro suavizado muy elegante).
*   **Tipografia Sugerida:**
    *   **Titulos:** Outfit o Arial (Negrita).
    *   **Cuerpo:** Inter o Arial (Regular).
*   **Lema Corporativo (Footer):**
    *   *"Infraestructura que piensa. Ingenieria estrategica desde el Meta."*

---

## 2. Formato de Salida Compatible con Google Docs y Word

Para garantizar que el usuario pueda editar y trabajar el documento directamente en **Google Docs o Microsoft Word**, la IA debe estructurar el resultado bajo dos modalidades de salida segun lo solicite el usuario:

### Metodo A: Salida en HTML Estilizado Inline (Recomendado para Maxima Fidelidad)
El formato HTML estructurado con estilos CSS en linea (inline) es el metodo mas potente, ya que tanto MS Word como Google Docs lo leen de forma nativa. Al copiar el codigo HTML renderizado (o guardarlo como archivo `.html` y abrirlo en Word/Docs), se conservan exactamente todos los colores, margenes, bordes y fuentes.

**Reglas de Formateo HTML:**
*   Usar un contenedor principal con tipografia Arial, interlineado de `1.5`, margenes y un color de texto `#121714` para el cuerpo.
*   Los titulos `<h1>` deben llevar estilos inline: `color: #1F8C4E; font-family: Arial, sans-serif; font-size: 24pt; border-bottom: 2px solid #C8A94C; padding-bottom: 4px; margin-top: 20px;`.
*   Los subtitulos `<h2>` deben llevar estilos inline: `color: #C8A94C; font-family: Arial, sans-serif; font-size: 16pt; margin-top: 15px;`.
*   Los bloques de notas/destacados deben estructurarse como `blockquote` con: `border-left: 4px solid #C8A94C; background-color: #F4F6F4; padding: 12px; margin: 15px 0; border-radius: 0 8px 8px 0;`.
*   Las tablas deben formatearse con estilos explicitos: `border-collapse: collapse; width: 100%;`. El encabezado `<th>` debe llevar `background-color: #1F8C4E; color: #FFFFFF; padding: 8px; border: 1px solid #C8A94C;`. Las filas de datos `<td>` deben llevar `padding: 8px; border: 1px solid #DDDDDD;` alternando fondos suaves `#F4F6F4` para filas pares.

### Metodo B: Salida en Markdown Limpio (Para Copia Rapida)
Ideal para copiar y pegar en editores que soporten Markdown (como el propio Google Docs con la extension Markdown o en editores de codigo).
*   Usar `#` para Titulos principales y `##` para secundarios.
*   Estructurar las tablas usando la sintaxis estandar de Markdown.
*   Utilizar bloques de cita `>` para notas importantes e identificar los acentos de color mediante descripciones de texto o etiquetas sutiles.

---

## 3. Estructura de Documento Academico/Corporativo AxioPri

Al invocar esta skill para redactar un informe o trabajo universitario para la **Universidad La Gran Colombia**, la IA estructurara el contenido con la siguiente arquitectura:

1.  **Portada Estilizada:**
    *   Alineado a la derecha: `UNIVERSIDAD LA GRAN COLOMBIA` (Academico) o `AXIOPRI S.A.S BIC` (Corporativo).
    *   Titulo del documento en tamano grande (Verde Moriche).
    *   Subtitulo del documento (Dorado Llanero / Gold).
    *   Bloque de metadatos:
        *   **Autor:** Juan Pablo Velásquez Prieto (CEO & Fundador)
        *   **Origen:** Villavicencio, Meta (Orinoquia)
        *   **Area de Trabajo:** [Area academica o consultoria del proyecto]
        *   **Fecha:** [Mes] [Año]
2.  **Tabla de Contenido / Introduccion**
3.  **Cuerpo del Informe:** Desarrollado con secciones claras (`h2` y `h3`), tablas de datos con el diseno de la paleta y bloques destacados para notas de campo y geotecnia.
4.  **Conclusiones e Impacto Sostenible (Capa BIC):** Una seccion obligatoria que describe como el proyecto o tematica se alinea con la sostenibilidad, la descarbonizacion, el impacto social regional en el Meta o la transformacion digital.
5.  **Pie de Pagina (Footer):** En cursiva y centrado: *"Infraestructura que piensa. Ingenieria estrategica desde el Meta."*

---

## 4. Tono de Comunicacion (La Voz del Meta)

La redaccion de los informes debe fusionar:
*   **El Sabio e Innovador:** Rigor tecnico de ingenieria civil, metodologias BIM (NTC-ISO 19650) y optimizacion algoritmica de Inteligencia Artificial.
*   **La Calidez y Resistencia del Llano:** Expresiones de comunicacion claras, honestas, con un profundo arraigo territorial y respeto al entorno natural de la Orinoquia colombiana.

---

## 5. Ejemplos de Invocacion y Casos de Uso

### Caso 1: Redactar un Informe de Universidad
*   *Usuario:* `/axiopri-document-styling Redacta un informe tecnico sobre la dinamica de suelos y geologia aplicada en las sabanas del departamento del Meta para mi materia de Geotecnia.`
*   *Comportamiento de la IA:* La IA leera esta skill, generara el informe estructurando la portada de la Universidad La Gran Colombia, la introduccion, el desarrollo tecnico y la capa BIC, entregando el codigo HTML estilizado en linea listo para ser copiado en Microsoft Word o Google Docs.

### Caso 2: Estructurar un Documento Corporativo
*   *Usuario:* `/axiopri-document-styling Genera una propuesta tecnica de servicios de consultoria de auditoria automatizada de metrados para un cliente constructor en Villavicencio.`
*   *Comportamiento de la IA:* Aplicara el tono corporativo de AxioPri, mantendra el perfil Asset-Light, formateara la propuesta con la paleta de colores Verde Moriche y Dorado / Gold, e inyectara el lema en el pie de pagina, presentandolo en HTML editable.
